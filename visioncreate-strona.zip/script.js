(function(){
var $=function(s){return document.querySelector(s)};

/* menu mobilne */
var mb=$(".menu"),nv=$("#nav");
if(mb&&nv)mb.onclick=function(){var o=nv.classList.toggle("open");mb.setAttribute("aria-expanded",o)};

/* pasek postępu i podświetlenie kart pod myszką */
var pg=$("#prog");
if(pg)addEventListener("scroll",function(){var h=document.documentElement.scrollHeight-innerHeight;pg.style.width=(h>0?scrollY/h*100:0)+"%"},{passive:true});
document.addEventListener("pointermove",function(e){var c=e.target.closest&&e.target.closest(".card,.pcard");if(c){var r=c.getBoundingClientRect();c.style.setProperty("--mx",e.clientX-r.left+"px");c.style.setProperty("--my",e.clientY-r.top+"px")}});

/* portfolio */
var pf=document.getElementById("pf");
if(pf){
var PROJ=[
{n:"Vortex",t:"Strona wizytówka",url:"https://vortexdetail.github.io/",img:"projekt1.png"},
{n:"GRAD",t:"Strona + podstrony",url:"https://uslugiogrodniczegrad-design.github.io/Uslugi-Ogrodnicze-GRAD/",img:"projekt2.png"}
];
pf.innerHTML=PROJ.map(function(p){return '<a class="pcard rv" href="'+p.url+'" target="_blank" rel="noopener"><div class="thumb'+(p.img?' hasimg':'')+'">'+(p.img?'<img src="'+p.img+'" alt="'+p.n+'" loading="lazy">':'<div class="bw"><div class="bd"><i></i><i></i><i></i></div><div class="bl l1"></div><div class="bl l2"></div><div class="bt"><s></s><s></s><s></s></div></div>')+'</div><div class="pinfo"><h3>'+p.n+'</h3><p>'+p.t+'</p></div></a>'}).join("");
}

/* usługi */
var svc=document.getElementById("svc");
if(svc){
var SV=[
{t:"Landing Page",p:"449–899 zł",d:"Jednostronicowa strona nastawiona na jeden cel: zapytanie, zapis lub sprzedaż konkretnej oferty.",w:"Dla firm i osób, które promują jedną konkretną ofertę, produkt, wydarzenie lub kampanię reklamową.",g:"Jednostronicową stronę, która prowadzi odwiedzającego do jednego działania: zapytania, zapisu lub zakupu.",s:"Układ nastawiony na konwersję, sekcje oferty, przyciski wezwania do działania, formularz, wersja mobilna, szybkie ładowanie.",c:"4–7 dni roboczych"},
{t:"Strony wizytówki",p:"499–999 zł",d:"Prosta, elegancka strona, która przedstawia Twoją firmę, ofertę i dane kontaktowe. Idealna na start w internecie.",w:"Dla małych firm, freelancerów i usługodawców, którzy chcą pojawić się w internecie i pokazać swoją ofertę oraz kontakt.",g:"Gotową, responsywną stronę z dopasowanym projektem graficznym, czytelną ofertą i formularzem kontaktowym.",s:"Projekt graficzny, wdrożenie, dopasowanie do telefonów, formularz kontaktowy, podstawowe SEO, uruchomienie na Twojej domenie.",c:"5–10 dni roboczych"},
{t:"Redesign stron",p:"499–1 999 zł",d:"Odświeżamy wygląd i działanie istniejącej strony, aby była nowoczesna, szybka i czytelna.",w:"Dla firm, które mają już stronę, ale wygląda przestarzało, działa wolno albo słabo pozyskuje klientów.",g:"Odświeżoną, nowoczesną i szybką stronę, która zachowuje Twoje treści i charakter marki.",s:"Analiza obecnej strony, nowy projekt graficzny, poprawa układu i nawigacji, optymalizacja szybkości, dostosowanie do telefonów, przeniesienie treści.",c:"1–2 tygodnie"},
{t:"Rozbudowane strony internetowe",p:"1 099–1 999 zł",d:"Nowoczesne strony składające się ze strony głównej i kilku podstron, dopasowane do charakteru Twojej firmy.",w:"Dla firm, które potrzebują więcej niż jednej strony: oferty, informacji o firmie, realizacji, kontaktu i innych podstron.",g:"Nowoczesną, wielostronicową stronę z przejrzystym układem, responsywnym designem i intuicyjną nawigacją, dzięki której klienci łatwo znajdą najważniejsze informacje.",s:"Projekt graficzny, strona główna i podstrony, menu i nawigacja, wersja mobilna, formularz kontaktowy, podstawowe SEO, publikacja.",c:"7–14 dni roboczych"}
];
svc.innerHTML=SV.map(function(s,i){return '<button type="button" class="card svc rv" data-i="'+i+'"><span class="soon ok">Dostępne</span><h3>'+s.t+'</h3><span class="pr grad">'+s.p+'</span><p>'+s.d+'</p><small>Zobacz szczegóły</small></button>'}).join("");
var showSv=function(i,sc){var s=SV[i],dt=document.getElementById("detail");document.getElementById("dt").textContent=s.t;
 document.getElementById("dg").innerHTML='<div><b>Dla kogo</b><p>'+s.w+'</p></div><div><b>Co otrzymasz</b><p>'+s.g+'</p></div><div><b>Zakres prac</b><p>'+s.s+'</p></div><div><b>Czas realizacji</b><p>'+s.c+'</p></div>';
 svc.querySelectorAll(".svc").forEach(function(b,j){b.classList.toggle("act",j===i)});
 dt.classList.remove("pop");void dt.offsetWidth;dt.classList.add("pop");if(sc)dt.scrollIntoView({behavior:"smooth",block:"center"})};
svc.onclick=function(e){var b=e.target.closest(".svc");if(b)showSv(+b.dataset.i,true)};
showSv(0,false);
}

/* animacje przy przewijaniu */
var io=new IntersectionObserver(function(es){es.forEach(function(x){if(x.isIntersecting){x.target.classList.add("in");io.unobserve(x.target)}})},{threshold:.12});
document.querySelectorAll(".rv").forEach(function(el){io.observe(el)});

/* formularz kontaktowy */
var form=document.getElementById("f");
if(form){
var W3F_KEY=""; /* opcjonalnie: klucz z web3forms.com; gdy pusty, używany jest FormSubmit */
form.onsubmit=function(e){e.preventDefault();var f=e.target,ok=document.getElementById("ok");
 if(!f.imie.value||!f.email.value||!f.msg.value||!f.querySelector('[type=checkbox]').checked){ok.style.display="block";ok.textContent="Uzupełnij imię, e-mail, wiadomość i zaznacz zgodę.";return}
 var body="Imię: "+f.imie.value+"\nE-mail: "+f.email.value+"\nTelefon: "+f.tel.value+"\nTyp projektu: "+f.typ.value+"\nBudżet: "+f.budzet.value+"\n\n"+f.msg.value;
 var mail="mailto:visioncreate.kontakt@gmail.com?subject="+encodeURIComponent("Zapytanie ze strony VisionCreate")+"&body="+encodeURIComponent(body);
 var btn=f.querySelector("button[type=submit]"),old=btn.textContent;btn.disabled=true;btn.textContent="Wysyłanie… (może potrwać kilka minut)";ok.style.display="block";ok.textContent="";
 var data={name:f.imie.value,email:f.email.value,phone:f.tel.value,"typ projektu":f.typ.value,"budżet":f.budzet.value,message:f.msg.value,_subject:"Nowe zapytanie ze strony VisionCreate",_template:"table",_captcha:"false"};
 fetch(W3F_KEY?"https://api.web3forms.com/submit":"https://formsubmit.co/ajax/visioncreate.kontakt@gmail.com",{method:"POST",headers:{"Content-Type":"application/json",Accept:"application/json"},body:JSON.stringify(W3F_KEY?{access_key:W3F_KEY,subject:data._subject,name:data.name,email:data.email,phone:data.phone,"typ projektu":data["typ projektu"],"budżet":data["budżet"],message:data.message}:data)})
 .then(function(r){return r.json()})
 .then(function(j){if(j.success==="true"||j.success===true){f.reset();ok.textContent="Dziękujemy! Wiadomość została wysłana. Odpowiemy do 24 godzin."}else{var er=new Error(j.message||"");er.server=1;throw er}})
 .catch(function(er){console.error("Formularz kontaktowy:",er);
  var hint=location.protocol==="file:"?" Strona jest otwarta z dysku, a formularz działa dopiero po wgraniu na hosting.":"";
  var msg=er&&er.server?(/activat/i.test(er.message)?"Formularz czeka na jednorazową aktywację: kliknij link w e-mailu od FormSubmit wysłanym na visioncreate.kontakt@gmail.com (sprawdź też spam), potem wyślij ponownie.":"Serwis wysyłki zgłosił problem. Spróbuj ponownie za chwilę."):"Nie udało się wysłać wiadomości."+hint;
  ok.innerHTML=msg+' <a href="'+mail+'" style="color:var(--b)">Wyślij z programu pocztowego</a>.'})
 .finally(function(){btn.disabled=false;btn.textContent=old})};
}

/* kopiowanie e-maila i telefonu */
document.querySelectorAll(".cb").forEach(function(b){b.onclick=function(){var t=b.dataset.copy;
 function done(){b.textContent="Skopiowano";setTimeout(function(){b.textContent="Kopiuj"},1600)}
 function fb(){var a=document.createElement("textarea");a.value=t;a.style.position="fixed";a.style.opacity="0";document.body.appendChild(a);a.select();try{document.execCommand("copy")}catch(e){}a.remove();done()}
 if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(t).then(done,fb)}else fb()}});
})();
